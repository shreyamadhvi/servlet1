package shreya_servlet1;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author iiht
 */
public class user_pass {
       // TODO Auto-generated method stub
    String username; // Username of person
    String passwoedS; 
    String hint;
// Password of person
 
 String  user(String username )
 
 {return username;}
 
 
 String   pass(String password)
 {return password;}

    }
    

